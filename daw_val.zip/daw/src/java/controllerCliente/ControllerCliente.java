/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllerCliente;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.JOptionPane;
import modelCliente.Cliente;
import modelCliente.Conexion;
import modelCliente.Producto;
import modelCliente.Proveedor;
import modelCliente.Usuario;
import modelCliente.UsuarioValidator;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;



/**
 *
 * @author Miguel
 */
@Controller
//Anotacion para poder trabajar con usuarios en todos los metodos
//@SessionAttributes("usuario")
//Anotación URL.
@RequestMapping("/")
public class ControllerCliente {
    //Definimos la conexion
    Conexion cn = new Conexion(); //Conexion programa-base de datos
    Connection con = cn.connect(); //Camino por el que viajan los datos
     private UsuarioValidator usuarioValidar;
   //Creamos los constructores
    public ControllerCliente() {
        //Instanciamos el objeto UsuarioValidator
        usuarioValidar = new UsuarioValidator();
    }

    public ControllerCliente(UsuarioValidator usu_val) {
        this.usuarioValidar = usu_val;
    }
   
    
    //EL metodo ModelAndView sirve para enlazar un solo formulario a un controller o un metodo del controller
    //El ModelAndView comunica el servlet con los jsp's.
    @RequestMapping(value="/crearcliente",method=RequestMethod.GET)
    public ModelAndView crearCliente(){
        Cliente cliente = new Cliente();
        //Con los parametros "commando" y es objeto, nos autorellena el objeto.
        //crearcliente es la página con la que enlazamos, command es el enlace, cliente es el objeto
        ModelAndView resultado = new ModelAndView("crearcliente");
        //Se puede enviar así,en Spring
            //sendRedirect
        //Antes se usaba de esta forma
        //request.getRequestDispatcher("/WEB-INF/jsp/crearcliente.jsp").forward(request, response);
       //Al devolver el resultado, indicamos que debe dirigirse a crearcliente.
       resultado.addObject("cliente", cliente); 
       return resultado;
    }
     
    
    @RequestMapping(value="/crearcliente",method=RequestMethod.POST)
   //Con la anotacion de clase ModelAttributee indicamos que el objeto generico, es de tipo cliente.
   //Hacemos casting del cliente y creamos el objeto Model para enviar .
   public String crearCliente(@ModelAttribute("cliente") Cliente cliente,Model model){

        //Añadimos el cliente a la BD
        //Generamos la sentencia SQL
        String sql = "INSERT INTO cliente (cliente_nombre, cliente_apellido, edad) VALUES (?,?,?)";
        
        try {
            //Hacemos el Prepared Statement
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, cliente.getNombre());
            pst.setString(2, cliente.getApellido());
            pst.setInt(3, cliente.getEdad());
            pst.executeUpdate();
            
        } catch (SQLException ex) {
           
        }
        

        model.addAttribute("cliente",cliente);
        return "mostrarcliente";
    }
   @RequestMapping("/visualizarcliente")
   public String visualizarcliente(Model model){
       ArrayList<Cliente> listaClientes = new ArrayList<Cliente>();
       //Obtenemos los clientes de la BD
       
        String sql="SELECT * FROM cliente";
        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while(rs.next()){
                Cliente aux = new Cliente();
                aux.setNombre(rs.getString("cliente_nombre"));
                aux.setApellido(rs.getString("cliente_apellido"));
                //System.out.println(aux.getNombre());
                aux.setEdad(rs.getInt("edad"));
                aux.setId(rs.getInt("cliente_id"));
                listaClientes.add(aux);
                
            }
             model.addAttribute("lista",listaClientes);
      
        } catch (SQLException ex) {
            Logger.getLogger(ControllerCliente.class.getName()).log(Level.SEVERE, null, ex);
        }
       //Los añadimos a la ArrayList
       return "visualizarcliente";
   }
   
   //Metodo con URL amigable 
   @RequestMapping(value="/modificarcliente/{id}/",method=RequestMethod.GET)
  // public String modificarCliente(@RequestParam int id, Model model){
   public String modificarCliente(@PathVariable String id, Model model){
       //Creamos la sentencia SQL
       String sql="SELECT * FROM cliente WHERE cliente_id ="+id;
       //Creamos un cliente para poder extraer los datos del resultado del sql
       Cliente aux = new Cliente();
       try {
           
           Statement st = con.createStatement();
           ResultSet rs = st.executeQuery(sql);
           while(rs.next()){
               aux.setNombre(rs.getString("cliente_nombre"));
               aux.setApellido(rs.getString("cliente_apellido"));
               aux.setEdad(rs.getInt("edad"));
               aux.setId(rs.getInt("cliente_id"));
           }
           model.addAttribute("cliente",aux);
       } catch (Exception e) {
       }
        return "modificarcliente";
    }
    //Metodo de modificar con metodo POST
    @RequestMapping(value="/actualizarcliente",method=RequestMethod.POST)
    public String modificarCliente(@ModelAttribute("cliente") Cliente cliente,Model model){
    //Creamos la sentencia SQL
    
     
     

      
          String sql = "UPDATE cliente set cliente_nombre=?, cliente_apellido=?, edad=? WHERE cliente_id=?";
    //Hacemos el Prepared Statement
        try {
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, cliente.getNombre());
            pst.setString(2, cliente.getApellido());
            pst.setInt(3, cliente.getEdad());
            pst.setInt(4, cliente.getId());
            pst.executeUpdate();
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
         //Enviamos el objeto modificado a la vista
        model.addAttribute("cliente",cliente);
        //Reedirigimos a la página de la vista
        return "actualizarcliente";
    }
    @RequestMapping(value="/eliminar/{id}/",method=RequestMethod.GET)
    public String eliminarCliente(@PathVariable String id){
       //Creamos la sentencia SQL
      String sql ="DELETE FROM cliente WHERE cliente.cliente_id ="+id;
     
        try {
             Statement st = con.createStatement();
            st.execute(sql);
            System.out.println(sql);
            
        } catch (Exception e) {
            System.out.println(sql);
        }
        return "eliminar";
    }
    /*
    @RequestMapping("/obtenercliente")
     public String obtenerCliente(HttpServletRequest request, HttpServletResponse response, Model model){
         String name= request.getParameter("nombre");
         String lastname = request.getParameter("apellido1");
         model.addAttribute("nombre",name);
         model.addAttribute("apellido",lastname);
         return "crear cliente";
     }*/
     
  

    @RequestMapping(value="/crearproducto",method=RequestMethod.GET)
    public ModelAndView crearProducto(){
        Producto producto = new Producto();
        ModelAndView resultado = new ModelAndView("crearproducto");
       resultado.addObject("producto", producto); 
       return resultado;
    }
   @RequestMapping(value="/crearproducto",method=RequestMethod.POST)
   //Con la anotacion de clase ModelAttributee indicamos que el objeto generico, es de tipo cliente.
   //Hacemos casting del cliente y creamos el objeto Model para enviar .
   public String crearProducto(@ModelAttribute("producto") Producto producto,Model model){

        //Añadimos el cliente a la BD
        //Generamos la sentencia SQL
        String sql = "INSERT INTO producto (Nombre_producto, Cantidad_producto) VALUES (?,?)";
        
        try {
            //Hacemos el Prepared Statement
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1,producto.getNombre_producto());
            pst.setInt(2, producto.getCantidad_producto());
            pst.executeUpdate();
            
        } catch (SQLException ex) {
           
        }
        
       //Manera antigua
        //request.setAttribute("mensaje", msg);
        
        
        //Se puede enviar así,en Spring
            //sendRedirect
        //Antes se usaba de esta forma
        //request.getRequestDispatcher("/WEB-INF/jsp/crearcliente.jsp").forward(request, response);
        model.addAttribute("producto",producto);
        return "mostrarproducto";
    }
   @RequestMapping("/visualizarproducto")
   public String visualizarProducto(Model model){
       ArrayList<Producto> listaProductos = new ArrayList<Producto>();
       //Obtenemos los clientes de la BD
       
        String sql="SELECT * FROM producto";
        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while(rs.next()){
                Producto aux = new Producto();
                aux.setNombre_producto(rs.getString("Nombre_producto"));
               
                //System.out.println(aux.getNombre());
                aux.setCantidad_producto(rs.getInt("Cantidad_producto"));
                aux.setId_producto(rs.getInt("id_producto"));
                listaProductos.add(aux);
                
            }
             model.addAttribute("lista",listaProductos);
      
        } catch (SQLException ex) {
            Logger.getLogger(ControllerCliente.class.getName()).log(Level.SEVERE, null, ex);
        }
       //Los añadimos a la ArrayList
       return "visualizarproducto";
   }
    @RequestMapping(value="/eliminarproducto/{id}/",method=RequestMethod.GET)
    public String eliminarProducto(@PathVariable String id){
       //Creamos la sentencia SQL
      String sql ="DELETE FROM producto WHERE producto.id_producto ="+id;
     
        try {
             Statement st = con.createStatement();
            st.execute(sql);
            System.out.println(sql);
            
        } catch (Exception e) {
            System.out.println(sql);
        }
        return "eliminar_producto";
    }
       @RequestMapping(value="/modificarproducto/{id}/",method=RequestMethod.GET)
  // public String modificarCliente(@RequestParam int id, Model model){
   public String modificarProducto(@PathVariable String id, Model model){
       //Creamos la sentencia SQL
       String sql="SELECT * FROM producto WHERE id_producto ="+id;
       //Creamos un cliente para poder extraer los datos del resultado del sql
       Producto aux = new Producto();
       try {
           
           Statement st = con.createStatement();
           ResultSet rs = st.executeQuery(sql);
           while(rs.next()){
               aux.setNombre_producto(rs.getString("Nombre_producto"));
               aux.setCantidad_producto(rs.getInt("Cantidad_producto"));
               aux.setId_producto(rs.getInt("id_producto"));
           }
           model.addAttribute("producto",aux);
       } catch (Exception e) {
       }
        return "modificarproducto";
    }
   //Metodo de modificar con metodo POST
    @RequestMapping(value="/actualizarproducto",method=RequestMethod.POST)
    public String modificarProducto(@ModelAttribute("producto") Producto producto,Model model){
    //Creamos la sentencia SQL
    
          String sql = "UPDATE producto SET Nombre_producto = ?, `Cantidad_producto` = ? WHERE `producto`.`id_producto` = ?;";
    //Hacemos el Prepared Statement
        try {
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, producto.getNombre_producto());
            pst.setInt(2, producto.getCantidad_producto());
            pst.setInt(3, producto.getId_producto());
            pst.executeUpdate();
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
         //Enviamos el objeto modificado a la vista
        model.addAttribute("producto",producto);
        //Reedirigimos a la página de la vista
        return "actualizarproducto";
    }
    
    //Proveedores
    //Funcion de viualizar proveedores.
     @RequestMapping("/visualizarproveedor")
   public String visualizarProveedor(Model model){
       ArrayList<Proveedor> listaProveedor = new ArrayList<Proveedor>();
       //Obtenemos los clientes de la BD
       
        String sql="SELECT * FROM `proveedor`";
        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while(rs.next()){
                Proveedor aux = new Proveedor();
                aux.setNombre_proveedor(rs.getString("nombre_proveedor"));
               
                //System.out.println(aux.getNombre());
                aux.setIBAN_proveedor(rs.getString("IBAN_proveedor"));
                aux.setId(rs.getInt("id_proveedor"));
                listaProveedor.add(aux);
                
            }
             model.addAttribute("lista",listaProveedor);
      
        } catch (SQLException ex) {
            Logger.getLogger(ControllerCliente.class.getName()).log(Level.SEVERE, null, ex);
        }
       //Los añadimos a la ArrayList
       return "visualizarproveedor";
   }
   
   //Funcion de añadir proveedor por metodo Get
    @RequestMapping(value="/crearproveedor",method=RequestMethod.GET)
    public ModelAndView crearProveedor(){
        Proveedor proveedor = new Proveedor();
        ModelAndView resultado = new ModelAndView("crearproveedor");
       resultado.addObject("proveedor", proveedor); 
       return resultado;
    }
  @RequestMapping(value="/crearproveedor",method=RequestMethod.POST)
   //Con la anotacion de clase ModelAttributee indicamos que el objeto generico, es de tipo cliente.
   //Hacemos casting del cliente y creamos el objeto Model para enviar .
    public String crearProveedor(@ModelAttribute("proveedor") Proveedor proveedor,Model model){

        //Añadimos el proveedor a la BD
        //Generamos la sentencia SQL
        String sql = "INSERT INTO proveedor (nombre_proveedor, IBAN_proveedor) VALUES (?, ?);";
        
        try {
            //Hacemos el Prepared Statement
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1,proveedor.getNombre_proveedor());
            pst.setString(2, proveedor.getIBAN_proveedor());
            pst.executeUpdate();
            
        } catch (SQLException ex) {
           
        }
        
       
        model.addAttribute("proveedor",proveedor);
        return "mostrarproveedor";
    }
    //Funcion de eliminar proveedor mediante un ID
    @RequestMapping(value="/eliminarproveedor/{id}/",method=RequestMethod.GET)
    public String eliminarProveedor(@PathVariable String id){
       //Creamos la sentencia SQL
      String sql ="DELETE FROM proveedor WHERE proveedor.id_proveedor ="+id;
      
        try {
             Statement st = con.createStatement();
            st.execute(sql);
            System.out.println(sql);
            
        } catch (Exception e) {
            System.out.println(sql);
        }
        return "eliminar_proveedor";
    }
    //Funcion modificar proveedor por GET
    @RequestMapping(value="/modificarproveedor/{id}/",method=RequestMethod.GET)
  // public String modificarCliente(@RequestParam int id, Model model){
   public String modificarProveedor(@PathVariable String id, Model model){
       //Creamos la sentencia SQL
       String sql="SELECT * FROM proveedor WHERE id_proveedor ="+id;
       //Creamos un cliente para poder extraer los datos del resultado del sql
       Proveedor aux = new Proveedor();
       try {
           
           Statement st = con.createStatement();
           ResultSet rs = st.executeQuery(sql);
           while(rs.next()){
               aux.setNombre_proveedor(rs.getString("nombre_proveedor"));
               aux.setIBAN_proveedor(rs.getString("IBAN_proveedor"));
               aux.setId(rs.getInt("id_proveedor"));
           }
           model.addAttribute("proveedor",aux);
       } catch (Exception e) {
       }
        return "modificarproveedor";
    }
   
   //Metodo de modificar con metodo POST
    @RequestMapping(value="/actualizarproveedor",method=RequestMethod.POST)
    public String modificarProveedor(@ModelAttribute("proveedor") Proveedor proveedor,Model model){
    //Creamos la sentencia SQL
    
          String sql = "UPDATE proveedor SET nombre_proveedor = ?, IBAN_proveedor = ? WHERE proveedor.id_proveedor = ?;";
          
    //Hacemos el Prepared Statement
        try {
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, proveedor.getNombre_proveedor());
            pst.setString(2, proveedor.getIBAN_proveedor());
            pst.setInt(3, proveedor.getId());
            pst.executeUpdate();
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
         //Enviamos el objeto modificado a la vista
        model.addAttribute("proveedor",proveedor);
        //Reedirigimos a la página de la vista
        return "actualizarproveedor";
    }
    @RequestMapping(value="/login", method=RequestMethod.GET)
    //SI usamos el metodo String hay que recoger el Model y en el JSP usar el CommandName
    //Si usaramos el ModelAndView, hno hay que recoger nada pero en el JSP tenemos que usar CommandName="Comand Clase que queremos relacionar"
     public String loginUsuario(Model model){
       Usuario usuario = new Usuario();
        //ModelAndView resultado = new ModelAndView("login");
        model.addAttribute("usuario",usuario);
        
      // resultado.addObject("usuario", usuario); 
       return "login";
    }
     
    /**
     *
     * @param usuario
     * @param session
     * @param result
     * @return
     */
    @RequestMapping(value="/login", method=RequestMethod.POST)
      //Old method el metodo antiguo usa el HttpSession session
    //NEcesitamos el BindingResult para poder recuperar los errores
     public String loginUsuario( @ModelAttribute("usuario") Usuario usuario, HttpSession session,BindingResult result){
      //New method
      //public String loginUsuario(@ModelAttribute("usuario") Usuario usuario, Model model, BindingResult result){
          //El objeto result es el que contiene los errores
          //result.hasErrors();
          //Relacionamos el usuario que nos llega con el usuario validar
          this.usuarioValidar.validate(usuario, result);
          JOptionPane.showMessageDialog(null, result.hasErrors());
          if(result.hasErrors()){
              JOptionPane.showMessageDialog(null,"estoy dentro");
              return "login";
          }
          else{
          String sql = "SELECT * from usuarios where usu_nombre ='"+usuario.getUsu_nombre()+"' AND usu_contrasena='"+usuario.getUsu_pass()+"'";
          //System.out.println(sql);
         // usu_val.validate(cn, errors);
       Statement st;
       ResultSet rs;
        try {
            st = con.createStatement();
            rs = st.executeQuery(sql);
            //Comprobamos si los datos son ciertos
            if(rs.next()){
                //Si lo son, creamos al usuario
               // Usuario usuario = new Usuario();
                //usuario.setUsu_nombre(nombre);
                //usuario.setUsu_pass(pass);
                //Creamos una sesion vacia
                //HttpSession session = request.getSession();
                //Ponemos los datos a la sesion
                session.setAttribute("usuario", usuario); //old method
               // model.addAttribute("usuario",usuario);
                //Seleccionamos donde lo queremos enviar
                //response.sendRedirect("visualizarcliente.jsp");
                 return "crearcliente";
            }
            else{
                
                return "login";
            }
        } catch (Exception e) {
             JOptionPane.showMessageDialog(null,sql);
        }
        return "actualizarcliente";
        //Para matar la sessión hay que poner
        //sessionStatus.setComplete();
    }
     }
}
