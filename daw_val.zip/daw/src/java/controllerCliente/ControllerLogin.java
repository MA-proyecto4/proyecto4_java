/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllerCliente;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.JOptionPane;
import modelCliente.Conexion;
import modelCliente.Usuario;

/**
 *
 * @author Miguel
 */
public class ControllerLogin extends HttpServlet {

    Conexion cn = new Conexion(); //Conexion programa-base de datos
    Connection con = cn.connect(); //Camino por el que viajan los datos
    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
       String nombre = request.getParameter("usu_nombre");//Aquí ponemos el parametro que enviamos por el form, el String es el mismo nombre que el formulario
       String pass = request.getParameter("usu_password");
       String sql = "SELECT * from usuarios where usu_nombre ='"+nombre+"' AND usu_contrasena='"+pass+"'";
        
       Statement st;
       ResultSet rs;
        try {
            st = con.createStatement();
            rs = st.executeQuery(sql);
            //Comprobamos si los datos son ciertos
            if(rs.next()){
                //Si lo son, creamos al usuario
               // Usuario usuario = new Usuario();
                //usuario.setUsu_nombre(nombre);
                //usuario.setUsu_pass(pass);
                //Creamos una sesion vacia
                HttpSession session = request.getSession();
                //Ponemos los datos a la sesion
                session.setAttribute("nombre", nombre);
                //Seleccionamos donde lo queremos enviar
                response.sendRedirect("visualizarcliente.jsp");
                
            }
            else{
                String msg="Usuario o contraseña no existentes";
                request.setAttribute("error",msg);
                request.getRequestDispatcher("login.jsp").forward(request, response);
                //response.sendRedirect("login.jsp");
            }
        } catch (Exception e) {
             JOptionPane.showMessageDialog(null,sql);
        }
    }

    

}
