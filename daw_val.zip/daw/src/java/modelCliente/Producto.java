/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelCliente;

/**
 *
 * @author Miguel
 */
public class Producto {
    private int id_producto;
    private String nombre_producto;
    private int cantidad_producto;
    //Constructores

    public Producto() {
    }

    public Producto(String nombre_producto, int cantidad_producto) {
        this.nombre_producto = nombre_producto;
        this.cantidad_producto = cantidad_producto;
    }

    //Metodos accesores
    //Setters

    public void setId_producto(int id_producto) {
        this.id_producto = id_producto;
    }

    public void setNombre_producto(String nombre_producto) {
        this.nombre_producto = nombre_producto;
    }

    public void setCantidad_producto(int cantidad_producto) {
        this.cantidad_producto = cantidad_producto;
    }
    //Getters

    public int getId_producto() {
        return id_producto;
    }

    public String getNombre_producto() {
        return nombre_producto;
    }

    public int getCantidad_producto() {
        return cantidad_producto;
    }
    
}
