/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
     alert("hola");
 function validate(){
              /* var error ="";
                    if(document.getElementById("usu_nombre").value=="")
                    {
                        	error+="Nombre obligatorio \n";
                        	document.getElementById("usu_nombre").style.borderColor="red";
                    }
                    if(document.getElementById("usu_password").value=="")
                    {
                            error+="Contraseña obligatorio \n";
                            document.getElementById("usu_password").style.borderColor="red";
                    }
                    if(error!=""){
                            alert(error);
                            return false;
                    }
                    else{
                            return true;
                    }*/
     alert("hola");
        }
