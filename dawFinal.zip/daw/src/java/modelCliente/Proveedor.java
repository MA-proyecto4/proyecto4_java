/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelCliente;

/**
 *
 * @author Miguel
 */
public class Proveedor {
    private int id;
    private String nombre_proveedor;
    private String IBAN_proveedor;
    
    //COnstructores

    public Proveedor() {
    }

    public Proveedor(String nombre_proveedor, String IBAN_proveedor) {
        this.nombre_proveedor = nombre_proveedor;
        this.IBAN_proveedor = IBAN_proveedor;
    }

    public Proveedor(int id, String nombre_proveedor, String IBAN_proveedor) {
        this.id = id;
        this.nombre_proveedor = nombre_proveedor;
        this.IBAN_proveedor = IBAN_proveedor;
    }
    
    //Metodos accesores
        //Getters

    public int getId() {
        return id;
    }

    public String getNombre_proveedor() {
        return nombre_proveedor;
    }

    public String getIBAN_proveedor() {
        return IBAN_proveedor;
    }
        //Setters

    public void setId(int id) {
        this.id = id;
    }

    public void setNombre_proveedor(String nombre_proveedor) {
        this.nombre_proveedor = nombre_proveedor;
    }

    public void setIBAN_proveedor(String IBAN_proveedor) {
        this.IBAN_proveedor = IBAN_proveedor;
    }
    
}
