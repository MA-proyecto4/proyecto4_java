/*
 * Para poder validar una clase, necesitamos crear una clase con "nombre"validator
 */
package modelCliente;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

/**
 *
 * @author Miguel
 */
public class ClienteValidator implements Validator {
    //Importamos los metodos abstractos de la interfaz
    @Override//Con Override sobreescribimos el metodo
    public boolean supports(Class<?> type) {
        //Relacionamos la clase UsuarioValidator con Usuario
        return Usuario.class.isAssignableFrom(type);
    }

    @Override
        //Esta clase es la que valida usando expresiones regulares 
        //Con esta funcion valida usando el objeto padre Objectv -Siendo la clase de donde heredan todas- y la clase errores que es un arrayList
    public void validate(Object o, Errors errors) {
        //Transformamos el objeto genérico  de tipo O a objeto de tipo usuario
            //Este casting se realiza por normativa del FrameWork
        Usuario usuario = (Usuario)o;
        //Primero mandamos el objeto errors.
        //Luego el campo necesario que tiene que ser igual a la clase
        //El campo requerido
        //Mensaje de error
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "usu_nombre", "required.usu_nombre","El campo nombre es Milhouse");
        //Contraseña
         ValidationUtils.rejectIfEmptyOrWhitespace(errors, "usu_pass", "required.usu_pass","El campo contraseña es necesario");
      }
    
    
}
